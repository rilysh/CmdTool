/*
CmdTool Version-1.0 Created by MathInDOS
Copyright 2018-2020 MathInDOS

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the Software), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, andor sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions
The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
THE SOFTWARE IS PROVIDED AS IS, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 
 */



#include <stdio.h>
#include <conio.h>
#include <Windows.h>
#include <stdlib.h>

int main(int argc, char* argv[])
{
    if(argv[1] == NULL)
    {
        printf("CmdTool Version-1.0 created by MathInDOS\n\n");
        printf("::Usage::\n");
        printf("CmdTool.exe c [color code]\n");
        printf("CmdTool.exe k \n");
        printf("CmdTool.exe g [x pos] [y pos]\n");
        printf("CmdTool.exe a [string]\n");
        printf("CmdTool.exe s [seconds]\n\n");
        printf("Copyright (C) 2018-2020 MathInDOS\n");
        return 0;

    }

    if(*argv[1] == 'c')
    {
        if(argv[2] == NULL)
        {
            return 1;
        }
        HANDLE console = GetStdHandle(STD_OUTPUT_HANDLE);
        int color_code = atoi(argv[2]);
        SetConsoleTextAttribute(console, color_code);
        printf(argv[3]);
        return 0;
    }

    if(*argv[1] == 'k')
    {
        int _key = _getch();
        return(_key);
    }

    if(*argv[1] == 'g')
    {
        if(argv[2] == NULL || argv[3] == NULL)
        {
            return 1;
        }
        HANDLE console_Pos = GetStdHandle(STD_OUTPUT_HANDLE);
        COORD Pos;
        Pos.X = atoi(argv[2]);
        Pos.Y = atoi(argv[3]);
        SetConsoleCursorPosition(console_Pos, Pos);
        printf(argv[4]);
        return 0;
    }

    if(*argv[1] == 'a')
    {
        if(argv[2] == NULL)
        {
            return 1;

        }
        int len = strlen(argv[2]);
        for(int i = 0; i < len; i++)
        {
            printf("%d", argv[2][i]);
            return 0;
        }

    }

    if(*argv[1] == 's')
    {
        if(argv[2] == NULL)
        {
            return 1;
        }
        int _wait = atoi(argv[2]);
        Sleep(_wait * 1000);
        return 0;
    }
}